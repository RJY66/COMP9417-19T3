import pandas as pd
from sklearn import svm
from sklearn import preprocessing
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
import numpy as np
import matplotlib.pyplot as plt
import floatrange as fr


data1 = pd.read_excel('FlourishingDiffer_Score_PCA.xlsx')
dataset = data1.values
# initialize param range list
c_range_list = [0.00001, 0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000]
gamma_range_list = [0.00001, 0.0001, 0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000]
# input,output split
x = dataset[:, 1: 4]
y = dataset[:, -1]
min_max_scaler = preprocessing.MinMaxScaler()
processed_x = min_max_scaler.fit_transform(x)
para_score = {}
score_list = []
c_list = []
gamma_list = []

# for loop to find best param
for i in c_range_list:
    for j in gamma_range_list:
        clf = svm.SVC(kernel='rbf', probability=True, C=i, gamma=j)
        score = cross_val_score(clf, processed_x.astype(float), y.astype(float), cv=5, scoring='roc_auc')
        para_score[(i, j)] = np.mean(score)
        score_list.append(np.mean(score))
        #gamma_list.append(i)
        #c_list.append(i)

# show biggest auc and best(c,gamma)
for (p, s) in para_score.items():
    if s == max(para_score.values()):
        print(str(p)+": "+str(s))

# plot the C / gamma graph
#plt.plot(gamma_list, score_list)
#plt.xlabel('C')
#plt.ylabel('ROC_AUC')
#plt.show()