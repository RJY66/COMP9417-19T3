# using GridSearch to find best parameter

import pandas as pd
from sklearn import svm
from sklearn import preprocessing
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV,train_test_split
import numpy as np
import floatrange as fr
from sklearn import metrics
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt


# plot ROC_AUC
def plot_roc(labels, predict_prob):
    false_positive_rate, true_positive_rate, thresholds = roc_curve(labels, predict_prob)
    roc_auc = auc(false_positive_rate, true_positive_rate)
    plt.title('ROC')
    plt.plot(false_positive_rate, true_positive_rate, 'b', label='AUC = %0.4f'% roc_auc)
    plt.legend(loc='lower right')
    plt.plot([0, 1], [0, 1], 'r--')
    plt.ylabel('TPR')
    plt.xlabel('FPR')
    plt.show()


# SVM Classifier using cross validation
def svm_cross_validation(train_x, train_y):
    model = svm.SVC(kernel='rbf', probability=True)
    param_grid = {'C': [0.00001, 0.001, 0.01, 0.1, 1, 10, 100, 10000], 'gamma': [0.00001, 0.0001, 0.001, 0.01, 0.1, 1, 10, 100, 1000, 10000,0.07,7988,6166],'tol':[0.00001,0.0001,0.001]}
    grid_search = GridSearchCV(model, param_grid, scoring='roc_auc', cv=5)
    grid_search.fit(train_x, train_y)
    best_parameters = grid_search.best_estimator_.get_params()
    for para, val in list(best_parameters.items()):
        print(para, val)
    model = svm.SVC(kernel='rbf', C=best_parameters['C'], gamma=best_parameters['gamma'], probability=True)
    model.fit(train_x, train_y)
    return model


data = pd.read_excel('PanasPositive_Differ.xlsx')
dataset = data.values
# input,output split
x = dataset[:, 1: 50]
y = dataset[:, -1]
x1 = x.astype(float)
y1 = y.astype(int)
# min-max normalization
min_max_scaler = preprocessing.MinMaxScaler()
processed_x1 = min_max_scaler.fit_transform(x1)

# calculate some metrics, cv=5
clf = svm_cross_validation(processed_x1, y1)
score = cross_val_score(clf, processed_x1.astype(float), y1.astype(float), cv=5, scoring='precision')
print(np.mean(score))

