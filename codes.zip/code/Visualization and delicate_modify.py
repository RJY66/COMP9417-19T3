from sklearn.model_selection import cross_val_score
import numpy as np
from sklearn import preprocessing
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import matplotlib.pyplot as plt
'''
This py document is to adjust our random forest model then visualize it.

In fact, in another code our team has used grid_search to get a most optimal

combination. But it can not directly display our result through graph which

is more human readable. So the aim of this part code is to delicate modify some

feature and display these accuracy score in different score through picture.    
 

'''

# import data and prepocessing it
f  = pd.read_excel("/Users/zouwentao/Desktop/s3/comp9417/project/prj_data/Datas/PCA/RAW/Panas_Negative/PanasNegative_post.xlsx")
min_max_scaler = preprocessing.MinMaxScaler()

# print first 5 data to see the format of these data
print(f.head())
f = f.values

# Split these data into X and Y, because our data do not need to split
# into train and test.
print(f.shape)
user_name = f[:,0]
train_number = 23
Y = f[:,-1]
X = f[:,1:-2]
X = np.array(X).astype('float')
X = min_max_scaler.fit_transform(X)
Y = np.array(Y).astype('float')

# The range of each feature, we can change it when we adjust the model
k_range =range(1,2000)
i_range = range(1,2)
j_range = range(1,2)

# store all the scores of combination
k_scores = []
#store detial parameters of each combonation
max_ik_dic = {}



for k in k_range:
    for i in i_range:
        for j in j_range:
            # some important features of random forest, easy to adjust
            clf = RandomForestClassifier(max_depth=2,n_estimators= k,random_state=9,
                                         min_weight_fraction_leaf =0.1,max_leaf_nodes=4  )
            X_Train = X.astype('float')
            Y_Train = Y.astype('float')
            ########################################################################################################
            # # '''Print the evaluation indicators of the model, print when we needed'''                           #
            # print("recall is: "+str(cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='recall').mean()))      #
            # print("roc_auc is: "+str(cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='roc_auc').mean()))    #
            # print("accuracy is: "+str(cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='accuracy').mean()))  #
            # print("F1 is: "+str(cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='f1').mean()))              #
            # print("precision is: "+str(cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='precision').mean()))#
            ########################################################################################################
            scores = cross_val_score(clf, X_Train, Y_Train, cv=5, scoring='roc_auc')

            '''get mean value of score'''
            k_scores.append(scores.mean())
            max_ik_dic[scores.mean()] = (k,i,j)


#display graph
plt.plot( k_scores)
plt.xlabel("Times of adjustment")
plt.ylabel("Cross validated roc_auc")
# print most optimal data
print(max_ik_dic[max(k_scores)],max(k_scores))
plt.show()



