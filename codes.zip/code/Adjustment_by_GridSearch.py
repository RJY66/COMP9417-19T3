from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
import numpy as np
from sklearn import preprocessing
import pandas as pd
from sklearn.model_selection import GridSearchCV

'''
This py document is used to find the most optimal combination of all the features

( which combinations can get a high roc_auc score our team think it is optimal combinations) 

Our team have used grid_search to from millions combinations to select 1 optimal combinations

and get a good model.

Then we print some important indexes of our model in some different data_set, and compare

them through many indexes (which can reflect on our report). 
'''

def random_forest_cross_validation(train_x, train_y):
    '''
    Use grid_search to find the most optimal model
    '''
    model = RandomForestClassifier(min_weight_fraction_leaf = 0.1,random_state=9 )
    # it is different range of some features, which can easy adjust
    param_grid = {'max_depth': [1, 2, 3, 4, 5], 'n_estimators': range(1,200),'max_leaf_nodes':range(2,5)}
    grid_search = GridSearchCV(model, param_grid, scoring='roc_auc', cv=5)
    grid_search.fit(train_x, train_y)
    best_parameters = grid_search.best_estimator_.get_params()
    for para, val in list(best_parameters.items()):
        if para == 'max_depth' or para == 'n_estimators' or para == 'random_state' or para == 'max_leaf_nodes':
           # display each parameter in model
            print(para, val)

    model = RandomForestClassifier(min_weight_fraction_leaf = 0.1, max_depth=best_parameters['max_depth'], n_estimators=best_parameters['n_estimators'])
    model.fit(train_x, train_y)
    return model


# use panda to read excel
f  = pd.read_excel('/Users/zouwentao/Desktop/s3/comp9417/project/prj_data/Datas/PCA/RAW/Flourishing/FlourishingPost_Score.xlsx')

# use min_max_scaler to prepossessing
min_max_scaler = preprocessing.MinMaxScaler()

f = f.values
# print f shape to ensure if the data have loss
print(f.shape)

# extract and form standard format
user_name = f[:,0]
train_number = 23
Y = f[:,-1]
X = f[:,1:-2]
X = np.array(X).astype('float')
X = min_max_scaler.fit_transform(X)
Y = np.array(Y).astype('float')

# clf is the most optimal model selected by grid_search
clf = random_forest_cross_validation(X,Y)

# print some indexs of model
# roc_auc score
score = cross_val_score(clf, X.astype(float), Y.astype(float), cv=5, scoring='roc_auc').mean()
print('this roc_auc is ' + str(score))
# recall score
score = cross_val_score(clf, X.astype(float), Y.astype(float), cv=5, scoring='recall').mean()
print('this recall is ' + str(score))
# accuracy score
score = cross_val_score(clf, X.astype(float), Y.astype(float), cv=5, scoring='accuracy').mean()
print('this accuracy is ' + str(score))
# precision score
score = cross_val_score(clf, X.astype(float), Y.astype(float), cv=5, scoring='precision').mean()
print('this precision is ' + str(score))

