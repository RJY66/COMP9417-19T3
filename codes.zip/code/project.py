import os
import pandas as pd
import time
import numpy as np
from collections import defaultdict
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
darkPath = 'StudentLife_Dataset//Inputs//sensing//dark//'
lockPath = 'StudentLife_Dataset//Inputs//sensing//phonelock//'
chargePath = 'StudentLife_Dataset//Inputs//sensing//phonecharge//'
audioPath = 'StudentLife_Dataset//Inputs//sensing//audio//'
activityPath = 'StudentLife_Dataset//Inputs//sensing//activity//'
converPath = 'StudentLife_Dataset//Inputs//sensing//conversation//'
bluetoothPath = 'StudentLife_Dataset//Inputs//sensing//bluetooth//'
gpsPath = 'StudentLife_Dataset//Inputs//sensing//gps//'

allConversation = []
conversationDays = []
#each student's conversations
userConversation = [[] for _ in range(49)]

stuPos = 0
stuID = []

########################################
features ={
    #1)each student's average sleep duration
    'sleepDuration' : [0 for _ in range(49)],
    #2)total conversation duration of each student
    'totalConversation' : [0 for _ in range(49)],
    #3)average conversation duration of each student
    'averageConversation' : [0 for _ in range(49)],
    #4)number of shortConversation
    'shortConversation' : [0 for _ in range(49)],
    #5)number of middleConversation
    'middleConversation' : [0 for _ in range(49)],
    #6)number of longConversation
    'longConversation' : [0 for _ in range(49)],
    #7)countConversaton
    'countConversaton' : [0 for _ in range(49)],
    #8)each day's conversation times
    'dayConversationTimes' : [0 for _ in range(49)],
    #9)each day's conversation duration
    'dayConversationDuration' : [],
    #10)each day's number of shortConversation
    'dayShortConversation' : [0 for _ in range(49)],
    #11)each day's number of middleConversation
    'dayMiddleConversation' : [0 for _ in range(49)],
    #12)each day's number of longConversation
    'dayLongConversation' : [0 for _ in range(49)],
########################################
    #1)the total amount of bluetooth that encountered
    'Total_Bluetooth' : [],
    #2)the average amount of bluetooth that encountered everyday
    'Average_Bluetooth' : [],
    #3)the types of bluetootth encounterd in total
    'Bluetooth_MACs' : [],
    #4)the type of bluetooth >=1 every day
    'Bluetooth_Better_Macs' : [],
    #5)ratio
    'MACs_Ratio' : [],
    #6)good bluetooth
    'Good_Bluetooth' : [],
    #7)OK bluetooth
    'OK_Bluetooth' : [],
    #8)strength
    'Average_Bluetooth_Strength' : []
}
#get the sleepduration
def getSleepDuration(uID):
    global stuPos
    IDstring = ''
    if(uID < 10): IDstring = f'0{uID}'
    else : IDstring = str(uID)

    if(os.path.exists(darkPath + f'dark_u{IDstring}.csv') == False): return

    dataFrame = pd.read_csv(darkPath + f'dark_u{IDstring}.csv')
    mtx = dataFrame.values

    light = [0 for _ in range(67)]
    lock = [0 for _ in range(67)]
    charge = [0 for _ in range(67)]
    silence = [0 for _ in range(67)]
    stationary = [0 for _ in range(67)]
    # timeArray = time.localtime(start)
    # otherStyleTime = time.strftime("%Y--%m--%d %H:%M:%S", timeArray)
    # print(otherStyleTime)  # 2013--10--10 23:40:00

    for row in mtx[:] :
        timeStart = time.localtime(row[0])
        timeEnd = time.localtime(row[1])
        #print(timeStart,timeEnd)
        if(timeEnd.tm_yday == timeStart.tm_yday):
            light[timeStart.tm_yday - 86] += (timeEnd.tm_hour - timeStart.tm_hour) *3600 + (timeEnd.tm_min - timeStart.tm_min) * 60 + (timeEnd.tm_sec - timeStart.tm_sec)
        else:
            light[timeStart.tm_yday - 86] += (24 - timeStart.tm_hour) *3600 + (0 - timeStart.tm_min) * 60 + (0 - timeStart.tm_sec)
            light[timeStart.tm_yday - 86 + 1] += (timeEnd.tm_hour - 0) * 3600 + (
                        timeEnd.tm_min - 0) * 60 + (timeEnd.tm_sec - 0)

    dataFrame = pd.read_csv(lockPath + f'phonelock_u{IDstring}.csv')
    mtx = dataFrame.values

    for row in mtx[:] :
        timeStart = time.localtime(row[0])
        timeEnd = time.localtime(row[1])
        #print(timeStart,timeEnd)
        if(timeEnd.tm_yday == timeStart.tm_yday):
            lock[timeStart.tm_yday - 86] += (timeEnd.tm_hour - timeStart.tm_hour) *3600 + (timeEnd.tm_min - timeStart.tm_min) * 60 + (timeEnd.tm_sec - timeStart.tm_sec)
        else:
            lock[timeStart.tm_yday - 86] += (24 - timeStart.tm_hour) *3600 + (0 - timeStart.tm_min) * 60 + (0 - timeStart.tm_sec)
            lock[timeStart.tm_yday - 86 + 1] += (timeEnd.tm_hour - 0) * 3600 + (
                        timeEnd.tm_min - 0) * 60 + (timeEnd.tm_sec - 0)

    dataFrame = pd.read_csv(chargePath + f'phonecharge_u{IDstring}.csv')
    mtx = dataFrame.values

    for row in mtx[:] :
        timeStart = time.localtime(row[0])
        timeEnd = time.localtime(row[1])
        if(timeEnd.tm_yday == timeStart.tm_yday):
            charge[timeStart.tm_yday - 86] += (timeEnd.tm_hour - timeStart.tm_hour) *3600 + (timeEnd.tm_min - timeStart.tm_min) * 60 + (timeEnd.tm_sec - timeStart.tm_sec)
        else:
            charge[timeStart.tm_yday - 86] += (24 - timeStart.tm_hour) *3600 + (0 - timeStart.tm_min) * 60 + (0 - timeStart.tm_sec)
            charge[timeStart.tm_yday - 86 + 1] += (timeEnd.tm_hour - 0) * 3600 + (
                        timeEnd.tm_min - 0) * 60 + (timeEnd.tm_sec - 0)

    dataFrame = pd.read_csv(audioPath + f'audio_u{IDstring}.csv')
    mtx = dataFrame.values
    pre = 0
    for row in mtx[:] :
        rowtime = time.localtime(row[0])
        if row[1] == 0 and pre != rowtime.tm_sec:
            silence[rowtime.tm_yday - 86] += 1
        if row[1] == 1 and pre == rowtime.tm_sec:
            silence[rowtime.tm_yday - 86] -= 1
        pre = rowtime.tm_sec

    dataFrame = pd.read_csv(gpsPath + f'gps_u{IDstring}.csv' , index_col=False)
    mtx = dataFrame.values
    preday = 0
    pretimestamp = 0
    for i in range(len(mtx)) :
        row = mtx[i]
        rowtime = time.localtime(row[0])
        rowday = rowtime.tm_yday
        if row[-1] == 'stationary' :
            if rowday != preday :
                stationary[rowday-86] += 600
            else :
                if int(row[0]) - pretimestamp > 600 :
                    stationary[rowday-86] += 600
                else :
                    stationary[rowday - 86] += int(row[0]) - pretimestamp

        preday = rowday
        pretimestamp = row[0]

    # Light (FI) 0.0415
    # Phone-lock (F2) 0.0512
    # Phone-off (F3) 0.0000
    # Phone-charging (F4) 0.0469
    # Stationary (F5) 0.5445
    # Silence (F6) 0.3484
    alpha = np.array([0.0415 ,0.0512 ,0.0469  , 0.3484 , 0.5445])
    cnt = 0
    for i in range(len(light)-1):
        if i==0 : continue
        tes = np.array([light[i], lock[i], charge[i], silence[i], stationary[i]])
        sl = np.dot(tes , alpha)
        if sl != 0 :
            features['sleepDuration'][stuPos] += sl
            cnt += 1
    features['sleepDuration'][stuPos] /= cnt
    stuPos += 1

for i in range(60) :
    getSleepDuration(i)
#get conversation features
def conoversation():
    def getConversation(uID , cnt):
        IDstring = ''
        if (uID < 10):
            IDstring = f'0{uID}'
        else:
            IDstring = str(uID)

        if (os.path.exists(converPath + f'conversation_u{IDstring}.csv') == False): return cnt

        dataFrame = pd.read_csv(converPath + f'conversation_u{IDstring}.csv')
        mtx = dataFrame.values
        ctConv = 0
        daycnt = set()
        for row in mtx:
            ctConv += 1
            differ = row[1] - row[0]
            features['totalConversation'][cnt] += differ
            userConversation[cnt].append(differ)
            allConversation.append(differ)
            daycnt.add(time.localtime(row[0]).tm_yday)

        features['averageConversation'][cnt] = features['totalConversation'][cnt] / ctConv
        features['countConversaton'][cnt] = ctConv
        features['dayConversationDuration'].append(features['totalConversation'][cnt] / len(daycnt))
        features['dayConversationTimes'][cnt] = ctConv / len(daycnt)
        conversationDays.append(len(daycnt))

        return cnt+1
    cnt = 0
    for i in range(60) :
        cnt = getConversation(i , cnt)

    converModle = KMeans(3)
    converModle.fit(np.array(allConversation).reshape(-1,1))

    for i in range(49) :
        convCt = [0 , 0 ,0]
        lables = converModle.predict(np.array(userConversation[i]).reshape(-1,1))
        for lable in lables :
            convCt[lable] += 1
        features['shortConversation'][i] = convCt[0]
        features['middleConversation'][i] = convCt[1]
        features['longConversation'][i] = convCt[2]
        features['dayShortConversation'][i] = convCt[0] / conversationDays[i]
        features['dayMiddleConversation'][i] = convCt[1] / conversationDays[i]
        features['dayLongConversation'][i] = convCt[2] / conversationDays[i]
#get bluetooth features
def blue():
    def bluetooth(uID):
        MACdic = defaultdict(lambda : 0)
        IDstring = ''
        if (uID < 10):
            IDstring = f'0{uID}'
        else:
            IDstring = str(uID)

        if (os.path.exists(bluetoothPath + f'bt_u{IDstring}.csv') == False): return

        stuID.append(f'u{IDstring}')

        dataFrame = pd.read_csv(bluetoothPath + f'bt_u{IDstring}.csv')
        mtx = dataFrame.values
        bluetoothCt = 0
        days = set()
        strength = 0
        strCT = 0
        goodCT = 0
        okCT= 0
        for row in mtx :
            bluetoothCt += 1
            days.add(time.localtime(row[0]).tm_yday)
            MACdic[row[1]] += 1
            if row[3] <= 0 and row[3] >= -100:
                strength += row[3]
                strCT += 1
                if(row[3]>=-50):
                    goodCT += 1
                if(row[3] >= -70):
                    okCT += 1

        features['Total_Bluetooth'].append(bluetoothCt)
        features['Average_Bluetooth'].append(bluetoothCt/len(days))
        cnt = 0
        for MAC in MACdic :
            if(MACdic[MAC] / len(days)) >= 1 : cnt+=1
        features['Bluetooth_MACs'].append(len(MACdic))
        features['Bluetooth_Better_Macs'].append(cnt)
        features['MACs_Ratio'].append(cnt/len(MACdic))

        features['Average_Bluetooth_Strength'].append(strength / strCT)
        features['Good_Bluetooth'].append(goodCT)
        features['OK_Bluetooth'].append(okCT)

    for i in range(60) :
        bluetooth(i)
conoversation()
blue()

#write to csv file
df = pd.DataFrame(features , index=stuID)
df.to_csv('features.csv')
#PCA feature generates
df = pd.read_csv('features.csv')
mtx = df.values
print(mtx)
pca = PCA(0.99)
newmtx = pca.fit_transform(mtx[: , 1:])
print(pca.explained_variance_ratio_)
pd.DataFrame(newmtx).to_csv('PCA.csv')