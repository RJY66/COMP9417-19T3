import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing

'''
This PY document is to display the importance of each feature our team used in

our model. Then our team can through these material to analysis，and extract some 

important feature or adjust our feature select.  
'''

# Through panda to read flourish_raw_data data
df_wine = pd.read_excel('/Users/zouwentao/Desktop/s3/comp9417/project/prj_data/Datas/PCA/RAW/Flourishing/FlourishingDiffer_Score_raw.xlsx')

# encode categorical data
df_wine.columns = [	'userid','sleepDuration','0 rate(audio)','1 rate(audio)','2 rate(audio)',
                    '0 rate(activity)',	'1 rate(activity)'	,'2 rate(activity)','3 rate(activity)',	'total_hour(dark)',
                    'morning_rate(dark)','noon_rate(dark)','night_rate(dark)','totalConversation','averageConversation',
                    'shortConversation','middleConversation','longConversation','countConversaton','dayConversationTimes',
                    'dayConversationDuration','dayShortConversation','dayMiddleConversation','dayLongConversation','Conversation_Duration_Day',
                'Conversation_Duration_Eve','Conversation_Duration_Nig','Conversation_Frequency_Day','Conversation_Frequency_Eve','Conversation_Frequency_Nig',
            'Total_Bluetooth','Average_Bluetooth','Bluetooth_MACs',	'Bluetooth_Better_Macs','MACs_Ratio',
            'Good_Bluetooth','OK_Bluetooth','Average_Bluetooth_Strength','avg_dis',	'accuracy_mid',
            'phonecharge_total','phonecharge_aver',	'phonelock_total','phonelock_aver',	'BSSID_total',
            'BSSID_average','freq_average',	'level_average','location_total','location_kinds_average',
            'inside_avg','differ','Y']

# print the uID to ensure not miss
print('class labels:', np.unique(df_wine['userid']))

# ensure the shape of the data
f = df_wine.values
print(f.shape)


# preprocessing the data split data set into X_train and y_train
# then normalization data(MIN_MAX)
min_max_scaler = preprocessing.MinMaxScaler()
user_name = f[:,0]
train_number = 23
Y = f[:,-1]
X = f[:,1:-2]
X = np.array(X).astype('float')
X_train = min_max_scaler.fit_transform(X)
y_train = np.array(Y).astype('float')

# Decision tree model does not rely on feature scaling
# Random forest assessment feature importance
feat_labels = df_wine.columns[1:]
forest = RandomForestClassifier(n_estimators=19, max_depth=1, random_state=0)
forest.fit(X_train, y_train)
importances = forest.feature_importances_
indices = np.argsort(importances)[::-1]
for f in range(X_train.shape[1]):
    # Give the calculation of the average impurity attenuation of 1-200
    # decision trees to assess the importance of the feature
    print("%2d) %-*s %f" % (f + 1, 30, feat_labels[f], importances[indices[f]]))

# visualization code part
plt.title('Feature Importance-RandomForest')
plt.bar(range(X_train.shape[1]), importances[indices], color='lightblue', align='center')
plt.xticks(range(X_train.shape[1]), feat_labels, rotation=90)
plt.xlim([-1, X_train.shape[1]])
plt.tight_layout()
plt.show()

# On this basis, the random forest sea can
# compress the data set through the threshold.
X_selected = forest.transform(X_train, threshold=0.15)
print(X_selected.shape)
'''
1) sleepDuration                  0.210526
 2) 0 rate(audio)                  0.105263
 3) 1 rate(audio)                  0.052632
 4) 2 rate(audio)                  0.052632
 5) 0 rate(activity)               0.052632
 6) 1 rate(activity)               0.052632
 7) 2 rate(activity)               0.052632
 8) 3 rate(activity)               0.052632
 9) total_hour(dark)               0.052632
10) morning_rate(dark)             0.052632
11) noon_rate(dark)                0.052632
12) night_rate(dark)               0.052632
13) totalConversation              0.052632
14) averageConversation            0.052632
15) shortConversation              0.052632
16) middleConversation             0.000000
17) longConversation               0.000000
18) countConversaton               0.000000
19) dayConversationTimes           0.000000
20) dayConversationDuration        0.000000
21) dayShortConversation           0.000000
22) dayMiddleConversation          0.000000
23) dayLongConversation            0.000000
24) Conversation_Duration_Day      0.000000
25) Conversation_Duration_Eve      0.000000
26) Conversation_Duration_Nig      0.000000
27) Conversation_Frequency_Day     0.000000
28) Conversation_Frequency_Eve     0.000000
29) Conversation_Frequency_Nig     0.000000
30) Total_Bluetooth                0.000000
31) Average_Bluetooth              0.000000
32) Bluetooth_MACs                 0.000000
33) Bluetooth_Better_Macs          0.000000
34) MACs_Ratio                     0.000000
35) Good_Bluetooth                 0.000000
36) OK_Bluetooth                   0.000000
37) Average_Bluetooth_Strength     0.000000
38) avg_dis                        0.000000
39) accuracy_mid                   0.000000
40) phonecharge_total              0.000000
41) phonecharge_aver               0.000000
42) phonelock_total                0.000000
43) phonelock_aver                 0.000000
44) BSSID_total                    0.000000
45) BSSID_average                  0.000000
46) freq_average                   0.000000
47) level_average                  0.000000
48) location_total                 0.000000
49) location_kinds_average         0.000000
50) inside_avg                     0.000000
'''
